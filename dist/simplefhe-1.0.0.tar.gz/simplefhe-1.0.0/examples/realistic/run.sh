#! /bin/bash
python3 1_keygen.py
python3 2_encrypt.py
python3 3_process.py
python3 4_decrypt.py
